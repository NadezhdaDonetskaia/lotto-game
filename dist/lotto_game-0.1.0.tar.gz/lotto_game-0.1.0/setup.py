# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lotto_game',
 'lotto_game.lotto_card',
 'lotto_game.lotto_games',
 'lotto_game.lotto_games.level_games',
 'lotto_game.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['start-game = lotto_game.scripts.start_game:start']}

setup_kwargs = {
    'name': 'lotto-game',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'Nella',
    'author_email': 'nella611@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
