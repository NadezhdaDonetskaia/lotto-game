import random
import os
import threading
from queue import Queue
from lotto_game.lotto_games.lotto_game import LottoGame


def timer(time=30):
    def decorator(func):
        def wrapper(*args, **kwargs):
            print(f"\nУ вас есть {time} секунд чтобы ввести ответ...\n")
            result = [False]

            def inner(*args, **kwargs):
                answer = func(*args, **kwargs)
                result[0] = answer

            # daemon=True обязателен для прерывая программы по истечению времени
            t = threading.Thread(target=inner, args=args, kwargs=kwargs, daemon=True)
            t.start()
            t.join(time)

            if t.is_alive():
                print("Время истекло. Вы проиграли")
                return False
            else:
                return result


        return wrapper

    return decorator


class SimpleLottoGame(LottoGame):
    @timer()
    def get_answer(self, number_keg):
        super().get_answer()

