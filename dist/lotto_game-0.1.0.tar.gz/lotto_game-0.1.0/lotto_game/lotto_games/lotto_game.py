import random


class LottoGame():
    def __init__(self, player1, player2):
        self.player1 = player1
        self.player2 = player2
        self.kegs = list(range(1, 91))

    def get_answer(self, number_keg):
        answer = input(f'{self.player1}\n{self.player2}\n'
                              f'Бочонок {number_keg} осталось {len(self.kegs)}\n'
                              f'Хотите зачеркнуть? y/n: \n')
        print(f'я получил ответ в get_answer {answer} и возвращаю его')
        return answer

    def rounds(self):
        n = random.choice(self.kegs)
        self.kegs.remove(n)
        player_answer = self.get_answer(n)
        print(f'я получил ответ в rounds {player_answer}')
        result_round = self.is_correct_answer(player_answer, n)
        print(f'я его проверил и возвращаю {result_round}')
        return result_round

    def is_correct_answer(self, answer, num):
        if answer == 'y':
            if num not in self.player1.nums:
                print(f'{self.player1.name} проиграл!')
                return False
            else:
                self.player1.cross_out_num(num)
        else:
            if num in self.player1.nums:
                print(f'{self.player1.name} проиграл!')
                return False
        self.player2.cross_out_num(num)
        if len(self.player1.nums) == 0:
            print(f'{self.player1.name} победил!')
            return False
        elif len(self.player2.nums) == 0:
            print(f'Компьютер выиграл!')
            return False
        return True

    def start(self):
        while True:
            result = self.rounds()
            print(f'я обрабатываю каждый раунд и сейчас ответ {result}')
            if not result:
                print('а сейчас я должен остановить программу')
                break
            print(f'и я не заканчиваю программу')
