#!/usr/bin/env python
from lotto_game import game_engine


def start():
    game = game_engine()
    game.start()


if __name__ == '__main__':
    start()
