from lotto_game.lotto_games.level_games.simple import timer
from lotto_game.lotto_games.lotto_game import LottoGame


class MiddleLottoGame(LottoGame):

    @timer(time=10)
    def rounds(self):
        super().rounds()
