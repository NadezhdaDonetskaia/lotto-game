import random
from lotto_game.lotto_games.level_games.simple import timer
from lotto_game.lotto_games.lotto_game import LottoGame


class HardLottoGame(LottoGame):

    time = 30

    def set_time(self):
        remaining_percentage = len(self.kegs) / 90
        reduced_time = time * remaining_percentage
        print(f'Оставшееся время {reduced_time}\n')

    @timer(time)
    def rounds(self):
        n = random.choice(self.kegs)
        self.kegs.remove(n)
        player_answer = input(f'{self.player1}\n{self.player2}\n'
                              f'Бочонок {n} осталось {len(self.kegs)}\n'
                              f'Хотите зачеркнуть? y/n: \n')
        self.set_time()
        return self.is_correct_answer(player_answer, n)





